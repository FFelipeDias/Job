package pctConversor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class Conversor extends JFrame implements ActionListener{
	
	private JPanel painel;
	private JButton btnInverter;
	private JLabel lblRomano;
	private JLabel lblArabico;
	private JTextField txtRomano;
	private JTextField txtArabico;
	private JButton btnConfirmar;
	private String str;
	private final String[] romanSymb = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
	private final int[] romanVal= {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
	
	public Conversor() {
		super();
		lblArabico = new JLabel("N�mero Ar�bico", (int) CENTER_ALIGNMENT);
		lblRomano = new JLabel("N�mero Romano", (int) CENTER_ALIGNMENT);
		txtRomano = new JTextField();
		txtArabico = new JTextField();
		btnConfirmar = new JButton("Confirmar");
		btnInverter = new JButton("Inverter");
		painel = new JPanel(new GridLayout(3, 3, 5, 5));
		
		painel.add(lblArabico);
		painel.add(lblRomano);
		painel.add(txtArabico);
		painel.add(txtRomano);
		painel.add(btnConfirmar);
		painel.add(btnInverter);
		add(painel);
		
		
		btnInverter.addActionListener(this);
		btnConfirmar.addActionListener(this);
		
		lblRomano.setFont(new Font("Verdana",Font.BOLD,14));
		lblArabico.setFont(new Font("Verdana",Font.BOLD,14));
		txtRomano.setFont(new Font("Verdana",Font.BOLD,18));
		txtArabico.setFont(new Font("Verdana",Font.BOLD,18));
		btnConfirmar.setFont(new Font("Verdana",Font.BOLD,18));
		btnInverter.setFont(new Font("Verdana",Font.BOLD,18));
		
		painel.getRootPane().setDefaultButton(btnConfirmar);
		
        setSize(320,200);
        setVisible(true);
        setResizable(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Conversor de N�meros");
        txtRomano.setEnabled(false);
        txtRomano.setDisabledTextColor(Color.DARK_GRAY);
        txtArabico.setDisabledTextColor(Color.DARK_GRAY);
		
	}

	public static void main(String[] args) {
		@SuppressWarnings("unused")
		Conversor P  = new Conversor();

	}
	

	@Override

	public void actionPerformed(ActionEvent e) {
//		Mudar Sentido
		if(e.getSource()==btnInverter)
        {
			inverterOp();
        }
		
//		Confirmar
		if(e.getSource()==btnConfirmar)
        {
            if(txtRomano.isEnabled()) {
            	str = txtRomano.getText();
            	txtArabico.setText(romanToArabic(str));
    			txtRomano.requestFocus();
            }else {
            	str = txtArabico.getText();
            	txtRomano.setText(arabicToRoman(str));
    			txtArabico.requestFocus();
            }
        }
			
	}
	
//	Inverte o Sentido da Opera��o
	private void inverterOp() {
		txtRomano.setText("");
		txtArabico.setText("");
		
		if(txtRomano.isEnabled()) {
			txtRomano.setEnabled(false);
			txtArabico.setEnabled(true);
			txtArabico.requestFocus();
		}else {
			txtRomano.setEnabled(true);
			txtArabico.setEnabled(false);
			txtRomano.requestFocus();
		}
	}
	
//	Converte Ar�bico para Romano
	private String arabicToRoman(String arabicStr) {
		String romanStr = "";
		int intArabic;
		try {
			intArabic = Integer.parseInt(arabicStr);
//			Verificador de limite
			if (intArabic >=5000 || intArabic < 1) {
				throw new NumberFormatException();
			}
			
			int aux = 0;
			int mod = intArabic;
		
			for (int i = 0; i < romanSymb.length; i++) {
				aux = (mod / romanVal[i]);
				mod = (mod % romanVal[i]);
				for (int j = 0; j < aux; j++) {
					romanStr += romanSymb[i];
				}
			}
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(painel, "Insira apenas n�meros entre 1 e 4999", "Valor Inv�lido",
					JOptionPane.INFORMATION_MESSAGE);
		}
		return romanStr;
	}
	
//	Converte Romano para Ar�bico
	private String romanToArabic(String romanStr) {
		String str = "";
		try {
			int arabicInt = 0;
			str = romanStr.toUpperCase();
			String aux = "";
			String aux3 = "";
			int flag = 0;

			for (int i = 0; i < str.length(); i++) {
				aux = str.substring(i,i+1);
				if (flag != 0) {
					flag--;
				}

				if(i+1 != str.length()) {
					aux3 = str.substring(i,i+2);
					for (int j = 0; j < romanSymb.length; j++) {
						if(aux3.equals(romanSymb[j])) {
							arabicInt += romanVal[j];
							flag = 2;
							break;
						}
					}
				}
//				Verifica se ja foi processado como par
				if (flag == 0) {
					for (int j = 0; j < romanSymb.length; j++) {
						if (aux.equals(romanSymb[j])) {
							arabicInt += romanVal[j];
							break;
						}
					}
//					Verifica caracter inv�lido
					if(arabicInt == 0) {
						throw new Exception("Invalid Char");
					}
				}
			}
			str = Integer.toString(arabicInt);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(painel, "Insira apenas os caracteres romanos: M, D, C, L, X, V, I", "Valor Inv�lido",
					JOptionPane.INFORMATION_MESSAGE);
			str = "";
			txtArabico.setText("");
			txtRomano.setText("");
		}
		return str;
	}

}
